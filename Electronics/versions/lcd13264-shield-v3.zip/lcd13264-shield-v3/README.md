# Pax Instruments
# lcd12364-shield

Developed by <person(s) name> for [Pax Instruments](http://paxinstruments.com/), an original design.

## Overview
This is the electronics for the Pax Instruments JT-100 Junction Thermometer designed in Cadsoft Eagle.

## License
```
Place the license statement here
```